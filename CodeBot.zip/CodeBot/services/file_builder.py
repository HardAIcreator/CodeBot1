import os
import shutil
import zipfile
from typing import List, Dict


class FileBuilder:
    """Сохраняет файлы, сгенерированные ИИ, на диск и пакует их в архив при необходимости."""

    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)

    def _user_dir(self, user_id: int) -> str:
        path = os.path.join(self.base_dir, str(user_id))
        os.makedirs(path, exist_ok=True)
        return path

    def save_files(self, user_id: int, files: List[Dict[str, str]]) -> List[str]:
        """Сохраняет файлы на диск, возвращает список абсолютных путей."""
        user_dir = self._user_dir(user_id)
        # очищаем папку перед новой генерацией, чтобы не накапливался мусор
        for item in os.listdir(user_dir):
            item_path = os.path.join(user_dir, item)
            if os.path.isfile(item_path):
                os.remove(item_path)
            elif os.path.isdir(item_path):
                shutil.rmtree(item_path)

        saved_paths = []
        for file in files:
            filename = file["filename"]
            content = file["content"]

            # поддержка вложенных путей типа handlers/main.py
            full_path = os.path.join(user_dir, filename)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            with open(full_path, "w", encoding="utf-8") as f:
                f.write(content)
            saved_paths.append(full_path)

        return saved_paths

    def make_zip(self, user_id: int, paths: List[str], zip_name: str = "project.zip") -> str:
        user_dir = self._user_dir(user_id)
        zip_path = os.path.join(user_dir, zip_name)
        if os.path.exists(zip_path):
            os.remove(zip_path)

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in paths:
                arcname = os.path.relpath(path, user_dir)
                zf.write(path, arcname)

        return zip_path
