import json
from typing import List, Tuple

from openai import AsyncOpenAI

SYSTEM_PROMPT = """\
Ты — ассистент-программист внутри Telegram-бота CodeBot.
Твоя задача — писать рабочий, чистый код по запросу пользователя.

Когда пользователь просит написать код, проект, сайт, игру или бота:
1. Сгенерируй один или несколько файлов, нужных для работы решения.
2. Каждый файл должен содержать готовый к использованию код (без сокращений типа "// остальное аналогично").
3. Дай короткий комментарий о том, что ты сделал и как запускать проект.

Отвечай СТРОГО в формате JSON, без markdown-обёртки, по схеме:
{
  "summary": "короткое описание того, что сделано и как это запустить",
  "files": [
    {"filename": "main.py", "content": "..."},
    {"filename": "README.md", "content": "..."}
  ]
}

Если пользователь просто задаёт вопрос, просит объяснить код или ведёт обычный
диалог без необходимости создавать файлы — верни "files": [] и весь ответ
помести в "summary".

Если пользователь прислал код с ошибкой и просит исправить — верни
исправленный код целиком в files, а в summary опиши, что было не так
(например: "Строка 37: NameError — переменная x не определена").
"""


class AIService:
    def __init__(self, api_key: str, model: str):
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model

    async def generate(
        self, user_message: str, history: List[Tuple[str, str]]
    ) -> dict:
        """
        history: список (role, content), role = 'user' | 'assistant'
        Возвращает dict: {"summary": str, "files": [{"filename","content"}, ...]}
        """
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        for role, content in history:
            messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": user_message})

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            response_format={"type": "json_object"},
            temperature=0.3,
        )

        raw = response.choices[0].message.content
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            # На случай, если модель всё же что-то добавила лишнее
            data = {"summary": raw, "files": []}

        data.setdefault("summary", "")
        data.setdefault("files", [])
        return data
