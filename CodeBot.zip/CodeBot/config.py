import os
from dataclasses import dataclass


@dataclass
class Config:
    bot_token: str
    openai_api_key: str
    openai_model: str = "gpt-4o-mini"
    db_path: str = "codebot.db"
    generated_dir: str = "generated"
    max_history_messages: int = 12  # сколько последних сообщений помнить


def load_config() -> Config:
    bot_token = os.getenv("BOT_TOKEN")
    openai_api_key = os.getenv("OPENAI_API_KEY")

    if not bot_token:
        raise RuntimeError("Не задан BOT_TOKEN в переменных окружения (.env)")
    if not openai_api_key:
        raise RuntimeError("Не задан OPENAI_API_KEY в переменных окружения (.env)")

    return Config(
        bot_token=bot_token,
        openai_api_key=openai_api_key,
        openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
    )
