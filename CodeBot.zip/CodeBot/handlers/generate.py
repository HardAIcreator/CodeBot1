from aiogram import Router, types
from aiogram.types import FSInputFile, BufferedInputFile

from database import Database
from services.ai import AIService
from services.file_builder import FileBuilder
from utils.code_check import check_python_syntax, guess_language

router = Router(name="generate")

MAX_INLINE_FILES = 1  # если файлов больше — шлём ZIP-архивом, а не по одному


async def process_request(
    message: types.Message,
    text: str,
    db: Database,
    ai: AIService,
    file_builder: FileBuilder,
):
    user_id = message.from_user.id
    await db.ensure_user(user_id, message.from_user.username)

    status_msg = await message.answer("⏳ Генерирую...")

    history = await db.get_history(user_id, limit=12)

    try:
        result = await ai.generate(text, history)
    except Exception as e:
        await status_msg.edit_text(f"❌ Ошибка при обращении к ИИ: {e}")
        return

    await db.add_message(user_id, "user", text)
    await db.add_message(user_id, "assistant", result.get("summary", ""))

    files = result.get("files", [])
    summary = result.get("summary", "Готово.")

    if not files:
        await status_msg.edit_text(summary)
        return

    # Сохраняем файлы на диск
    saved_paths = file_builder.save_files(user_id, files)

    # Проверка синтаксиса для python-файлов — небольшой бонус "запуск/проверка"
    issues = []
    for file in files:
        if file["filename"].endswith(".py"):
            ok, err = check_python_syntax(file["content"])
            if not ok:
                issues.append(f"❌ {file['filename']}: {err}")

    await status_msg.edit_text("📦 Проект готов" if len(files) > 1 else "✅ Создал проект")

    if issues:
        await message.answer("⚠️ Найдены проблемы:\n" + "\n".join(issues))
    elif any(f["filename"].endswith(".py") for f in files):
        await message.answer("✔ Ошибок нет (проверка синтаксиса пройдена)")

    if len(files) <= MAX_INLINE_FILES:
        for file, path in zip(files, saved_paths):
            doc = FSInputFile(path, filename=file["filename"])
            await message.answer_document(doc)
    else:
        zip_path = file_builder.make_zip(user_id, saved_paths)
        doc = FSInputFile(zip_path, filename="project.zip")
        file_list = "\n".join(f"📄 {f['filename']}" for f in files)
        await message.answer(f"Файлы проекта:\n{file_list}")
        await message.answer_document(doc, caption="📦 Проект упакован в архив")

    if summary:
        await message.answer(summary)


def register_generate_handlers(router_outer: Router):
    """Регистрирует обработчик обычных текстовых сообщений (без команд) как fallback-генерацию."""

    @router_outer.message()
    async def handle_any_text(
        message: types.Message,
        db: Database,
        ai: AIService,
        file_builder: FileBuilder,
    ):
        if not message.text:
            await message.answer("Я понимаю только текстовые запросы 🙂")
            return
        await process_request(message, message.text, db, ai, file_builder)
