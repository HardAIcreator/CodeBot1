from aiogram import Router, types
from aiogram.filters import Command

from database import Database
from services.ai import AIService
from services.file_builder import FileBuilder

router = Router(name="commands")

WELCOME_TEXT = (
    "👋 Привет! Я <b>CodeBot</b> — пишу код, проекты и сайты прямо в Telegram.\n\n"
    "Просто напиши, что нужно создать, например:\n"
    "• <i>Напиши калькулятор на Python</i>\n"
    "• <i>Сделай сайт интернет-магазина</i>\n"
    "• <i>Создай игру Змейка</i>\n\n"
    "Команды:\n"
    "/code — режим генерации проекта\n"
    "/clear — забыть историю диалога\n"
    "/help — помощь"
)


@router.message(Command("start"))
async def cmd_start(message: types.Message, db: Database):
    await db.ensure_user(message.from_user.id, message.from_user.username)
    await message.answer(WELCOME_TEXT)


@router.message(Command("help"))
async def cmd_help(message: types.Message):
    await message.answer(WELCOME_TEXT)


@router.message(Command("clear"))
async def cmd_clear(message: types.Message, db: Database):
    await db.clear_history(message.from_user.id)
    await message.answer("🧹 История диалога очищена.")


@router.message(Command("code"))
async def cmd_code(
    message: types.Message,
    db: Database,
    ai: AIService,
    file_builder: FileBuilder,
):
    text = message.text.replace("/code", "", 1).strip()
    if not text:
        await message.answer(
            "Напиши после команды, что сгенерировать.\n"
            "Пример: <code>/code Создай Telegram бота на aiogram</code>"
        )
        return

    from handlers.generate import process_request  # локальный импорт, чтобы избежать циклического импорта

    await process_request(message, text, db, ai, file_builder)
