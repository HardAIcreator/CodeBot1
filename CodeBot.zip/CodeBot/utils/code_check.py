import ast
from typing import Optional, Tuple


def check_python_syntax(code: str) -> Tuple[bool, Optional[str]]:
    """
    Проверяет код на синтаксические ошибки (без выполнения, безопасно).
    Возвращает (ok, error_message).
    """
    try:
        ast.parse(code)
        return True, None
    except SyntaxError as e:
        return False, f"Строка {e.lineno}: {e.msg}"


def guess_language(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    mapping = {
        "py": "python",
        "js": "javascript",
        "ts": "typescript",
        "html": "html",
        "css": "css",
        "cs": "csharp",
        "cpp": "cpp",
        "c": "c",
        "java": "java",
        "go": "go",
        "rs": "rust",
        "json": "json",
        "md": "markdown",
    }
    return mapping.get(ext, "text")
